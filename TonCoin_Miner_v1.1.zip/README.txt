WECLOME TO TONCOIN_MINER!  

1) Run in Ubuntu terminal:
./go YOUR_WALLET

For Example:
./go EQDR01bJgJwAxJw7yyji34KhSQQTGkEFS3b3FxKCyZRvVLOf

2) You will see in output:
804.38 MH/s : Win at 24h[1.62%] 100% Win at[61.6 days]
Its mean you need ~61 days for get 100 Coins, but if you lucker you can win at any seconds)


3) if you want to run on multiple GPUs:
a) create folder GPU0 for first GPU, GPU1 for second GPU, GPU2 for 3-th, etc...
b) copy all the miner file to each folder
с) open N-terminals at each folder ( each terminal has a path inside its folder, like"
test@test-Default-string:~/Desktop/GPU0$
test@test-Default-string:~/Desktop/GPU1$
test@test-Default-string:~/Desktop/GPU2$
etc..

d) 
in first terminal run:
./go_many EQDR01bJgJwAxJw7yyji34KhSQQTGkEFS3b3FxKCyZRvVLOf 0
in second terminal run:
./go_many EQDR01bJgJwAxJw7yyji34KhSQQTGkEFS3b3FxKCyZRvVLOf 1
third
./go_many EQDR01bJgJwAxJw7yyji34KhSQQTGkEFS3b3FxKCyZRvVLOf 2
etc...

See News: @TonCoin_Miner
09.12.21
